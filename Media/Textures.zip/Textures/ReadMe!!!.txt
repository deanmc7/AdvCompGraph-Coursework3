Hogwarts Castle:
This model Was Creaded In CSSJ, Modeling in AutoCad 2010
Exported to 3Ds Max 2010.
All rights Reservaded
Diego Lopez. 27/12/12, 16:28 GTM-6 Pacific Time
This model is just referded Hogwarts as a (Any) Name.